window.onerror = function(error, url, line) {
   log(error + " @ Line: " + line + " url: " + url);
};

var top_z = 10;
function bringToTop(element)
{
    element.style.zIndex = ++top_z;
}

function makeIcon(address)
{		
	return blockies.create({ seed:address.toLowerCase() ,size: 8,scale: 2});
}

function insertIconFirst(obj,address)
{
	obj.insertBefore(makeIcon(address), obj.firstChild);
}

function icon(address)
{
     var storageid = "icon"+address;
     var storedValue = localStorage.getItem(storageid);
     if(storedValue != null)
     {
	return storedValue;
     }
     var str = "<img src='" + makeIcon(address).toDataURL() + "'>";
     localStorage.setItem(storageid,str);
     return str;
}

function clearSelector(sel)
{	
	if(sel == null || sel == "undefined")	return;
	for(var i=sel.options.length-1;i>=0;i--)
	{
		sel.remove(i);
	}
}

var selected = null, x_pos = 0, y_pos = 0, x_elem = 0, y_elem = 0;


function _drag_init(elem) {				
    selected = elem;
    x_elem = x_pos - selected.offsetLeft;
    y_elem = y_pos - selected.offsetTop;
    bringToTop(elem);
}

function _move_elem(e) {
    x_pos = document.all ? window.event.clientX : e.pageX;
    y_pos = document.all ? window.event.clientY : e.pageY;
    if (selected !== null) {
	var dx = (x_pos - x_elem);
	var dy = (y_pos - y_elem);
	selected.style.left = dx + 'px';
	selected.style.top =  dy + 'px';

    }
}

function _destroy() {
    selected = null;
}

function get_next_panel_id()
{
	return panel_last_id++;
}

var objID = 0;
function getObjId()
{		
	return "obj_"+objID++;
}

function makeDragable(obj)
{
    obj.onmousedown = function (e) 
	{ 			
		if(e.target.className != obj.className) return;
		_drag_init(this);  
		return true; 
	};
}

function addText(parent,str,width)
{	
	if(width == "undefined")
	{
		var obj = document.createTextNode(str);
		parent.appendChild(obj);	
	}
	else
	{
		var obj = document.createElement('div');
		obj.style.display = "inline-block";
		obj.style.padding = "0px";
		obj.style.boarder = "0px";			
		obj.style.width = width+"px";			
		obj.style.overflow = "hidden";	
		t = document.createElement('obj');
		t.innerHTML = str;			
		obj.appendChild(t);
		parent.appendChild(obj);
		return obj;
	}
}

function addButton(parent,str)
{	
	var obj = document.createElement('button');
	obj.innerHTML = str;
	parent.appendChild(obj);
	return obj;
}

function addDiv(parent,id,x,y,width,height,dragable)
{
	var div = document.createElement('div');
	div.id = id;
	div.className = "panel";
	div.style.left = x+'px'; 
	div.style.top = y+'px';	
	if(width != "undefined") div.style.width = width; 
	if(height != "undefined") div.style.height = height; 
	if(dragable != "undefined" && dragable) makeDragable(div);
	//else div.style.position = "relative";
	parent.appendChild(div);
	return div;
}

function addInput(parent,width)
{
	var obj = document.createElement('input');
	obj.style.width = width;
	parent.appendChild(obj);
	return obj;
}

function addNum(parent,width)
{
	var obj = document.createElement('input');
	obj.setAttribute("type", "number"); 
	obj.style.width = width;
	parent.appendChild(obj);
	return obj;
}

function hasValue(sel)
{
	sel.getValue = function() {
		return sel.options[sel.selectedIndex].value;
	}
}

function addSelect(parent,width)
{
	var obj = document.createElement('select');
	obj.style.width = width;
	hasValue(obj);
	parent.appendChild(obj);
	return obj;
}

function addOption(select,str,value)
{
	var option =  document.createElement("option");
	option.innerHTML = str;
	option.value = value;
	select.add(option);
	return option;
}

function init_display()
{
	document.onmousemove = _move_elem;
	document.onmouseup = _destroy;		
}

function createOption(str,value)
{
	var option =  document.createElement("option");
	option.innerHTML = str;
	option.value = i;
	return option;	
}

var log_counter = 0;
var max_log = 15;
function log(str)
{
	var logdiv = document.getElementById("logdiv");
	var currentdate = new Date(); 
	var datetime = currentdate.getDate() + "/"
        + (currentdate.getMonth()+1)  + "/" 
        + currentdate.getFullYear() + ", "  
        + currentdate.getHours() + ":"  
        + currentdate.getMinutes() + ":" 
        + currentdate.getSeconds();

	var obj=document.createElement('div');
	obj.innerText = datetime + " > " + str;
	obj.style.color = "#888";
	logdiv.insertBefore(obj,logdiv.firstChild);
	if(log_counter++ > max_log) logdiv.removeChild(logdiv.lastChild);		
}
