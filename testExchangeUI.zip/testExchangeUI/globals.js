var apiURL = "http://localhost:8000";

var tokenABI = [{"constant":false,"inputs":[{"name":"spender","type":"address"},{"name":"value","type":"uint256"}],"name":"approve","outputs":[{"name":"ok","type":"bool"}],"type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"supply","type":"uint256"}],"type":"function"},{"constant":false,"inputs":[{"name":"from","type":"address"},{"name":"to","type":"address"},{"name":"value","type":"uint256"}],"name":"transferFrom","outputs":[{"name":"ok","type":"bool"}],"type":"function"},{"constant":true,"inputs":[{"name":"who","type":"address"}],"name":"balanceOf","outputs":[{"name":"value","type":"uint256"}],"type":"function"},{"constant":false,"inputs":[{"name":"to","type":"address"},{"name":"value","type":"uint256"}],"name":"transfer","outputs":[{"name":"ok","type":"bool"}],"type":"function"},{"constant":true,"inputs":[{"name":"owner","type":"address"},{"name":"spender","type":"address"}],"name":"allowance","outputs":[{"name":"_allowance","type":"uint256"}],"type":"function"},{"anonymous":false,"inputs":[{"indexed":true,"name":"from","type":"address"},{"indexed":true,"name":"to","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Transfer","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"owner","type":"address"},{"indexed":true,"name":"spender","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Approval","type":"event"}];



function getAccounts(web3)
{
	var accounts = [];
	for(i = 0; i < web3.eth.accounts.length; i++)
	{
		accounts[i] = {};			
		accounts[i].address = web3.eth.accounts[i];
		accounts[i].str = icon(accounts[i].address) + accounts[i].address;
		if(accounts[i].address == web3.eth.coinbase) accounts[i].str += " (coinbase)";
	}	
	
	return accounts;
}

function accSel(accounts,sel)
{
	if(sel == null || sel == "undefined") return;
	clearSelector(sel);
	for(i = 0; i < accounts.length; i++)
	{
		sel.add(createOption(accounts[i].str,i));
	}
	hasValue(sel);
	return sel;
}

	

