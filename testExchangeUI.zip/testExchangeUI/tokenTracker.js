var regAddress = "0x7828e320d20e58d87381C1a9291Bd8080d67c56a";

var regABI = [{"constant":true,"inputs":[{"name":"","type":"address"}],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"count","outputs":[{"name":"","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"}],"name":"index","outputs":[{"name":"","type":"uint256"}],"payable":false,"type":"function"},{"constant":false,"inputs":[{"name":"_addr","type":"address"},{"name":"_decimals","type":"uint256"},{"name":"_symbol","type":"string"},{"name":"_name","type":"string"}],"name":"set","outputs":[],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"owner","outputs":[{"name":"","type":"address"}],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"_index","type":"uint256"}],"name":"getIndex","outputs":[{"name":"_addr","type":"address"},{"name":"_decimals","type":"uint256"},{"name":"_symbol","type":"string"},{"name":"_name","type":"string"},{"name":"_tag","type":"string"}],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"_addr","type":"address"},{"name":"id","type":"string"}],"name":"getExtra","outputs":[{"name":"data","type":"string"}],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"}],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"_addr","type":"address"}],"name":"getAddress","outputs":[{"name":"_decimals","type":"uint256"},{"name":"_symbol","type":"string"},{"name":"_name","type":"string"},{"name":"_tag","type":"string"}],"payable":false,"type":"function"},{"constant":false,"inputs":[{"name":"_addr","type":"address"},{"name":"id","type":"string"},{"name":"data","type":"string"}],"name":"setExtra","outputs":[],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"}],"name":"decimals","outputs":[{"name":"","type":"uint256"}],"payable":false,"type":"function"},{"constant":false,"inputs":[{"name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"addr","outputs":[{"name":"","type":"address"}],"payable":false,"type":"function"}];

function getTokenTracker(web3,address) {	
	var currentAddress = regAddress;	
	if(typeof address != "undefined") currentAddress = address;
	return web3.eth.contract(regABI).at(currentAddress);
}

function getTokens(web3,tokenTracker) {

	var tokens = [];		
	var tokenCount =  tokenTracker.count();
	for(var i = 1; i <= tokenCount; i++)
	{
		var result = tokenTracker.getIndex(i);
		
		var t = {
			address: result[0],
			digits:result[1],
			symbol:result[2],
			name:result[3]				
		};		
		
		t.contract = web3.eth.contract(tokenABI).at(t.address);
		t.precision = new BigNumber(10).toPower(t.digits);
		
		tokens.push(t);
	}
	
	return tokens;
}

function getToken(tokens,address)
{
	if(typeof address == "undefined") return address;
	for(var i = 0; i < tokens.length; i++)
	{	
		if(tokens[i].address.toUpperCase() == address.toUpperCase()) return tokens[i];
	}
	return "undefined";
}

function getTokenBySymbol(tokens,symbol)
{
	for(var i = 0; i < tokens.length; i++)
	{	
		if(tokens[i].symbol.toUpperCase() == symbol.toUpperCase()) return tokens[i];
	}
	return "undefined";
}


function getTokenName(tokens,address)
{
	var t = getToken(tokens,address);
	if(t == "undefined") return address;
	return t.name;
}

function getTokenSymbol(tokens,address)
{	
	var t = getToken(tokens,address);
	if(t == "undefined") return address;
	return t.symbol;
}